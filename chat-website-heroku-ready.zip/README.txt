# Heroku-Ready Chat Website

## How to Deploy on Render or Heroku
1. Upload this folder to GitHub.
2. On Render: Create a new Web Service, connect GitHub repo.
   - Build Command: npm install
   - Start Command: npm start
3. On Heroku: Follow CLI steps (requires Git and account verification).

Default password: secret123
